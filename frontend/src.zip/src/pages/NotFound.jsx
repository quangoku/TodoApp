import React from "react";

export default function NotFound() {
  return <div>PAGE NOT FOUND</div>;
}
